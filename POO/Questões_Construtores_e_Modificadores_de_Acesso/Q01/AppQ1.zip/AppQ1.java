package Questões_Construtores_e_Modificadores_de_Acesso.Q01;

import java.util.Scanner;

public class AppQ1 {
    private boolean saida = false;
    private int escolha;
    
    public void main() {
        Scanner input = new Scanner(System.in);
        Liga liga = new Liga();

        liga.adicionar_time(new Time("Loud"));
        liga.adicionar_time(new Time("Pain"));
        liga.adicionar_time(new Time("Cloud 99"));

        while (saida == false) {
            System.out.print("\n");
            System.out.print(" ----- Liga Dos Times -----");
            System.out.print("\n\n");

            liga.printar_times();

            System.out.print("\n");
            System.out.print("[0] Sair");
            System.out.print("\n\n");

            System.out.print("Insira uma opção: ");
            escolha = input.nextInt();

            if(escolha == 0) {
                saida = true;
                input.close();
                return;
            } else if(escolha >= 1 && escolha <= liga.tamanho_liga()) {
                liga.verificar_times(escolha);
            } else {
                System.out.print("Insira uma opção válida!");
            }
        }
        input.close();
    }
}
