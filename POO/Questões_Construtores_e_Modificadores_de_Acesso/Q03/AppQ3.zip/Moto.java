package Questões_Construtores_e_Modificadores_de_Acesso.Q03;

public class Moto extends Veiculos {
    public Moto() {
        this.imposto = 0.10;
        this.tipo = "Moto";
    }
}
