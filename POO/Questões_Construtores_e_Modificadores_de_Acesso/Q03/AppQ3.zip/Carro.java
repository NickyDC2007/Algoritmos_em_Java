package Questões_Construtores_e_Modificadores_de_Acesso.Q03;

public class Carro extends Veiculos {
    public Carro() {
        this.imposto = 0.20;
        this.tipo = "Carro";
    }
}
