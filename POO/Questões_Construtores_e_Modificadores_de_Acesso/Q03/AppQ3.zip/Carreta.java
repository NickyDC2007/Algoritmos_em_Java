package Questões_Construtores_e_Modificadores_de_Acesso.Q03;

public class Carreta extends Veiculos {
    public Carreta() {
        this.imposto = 0.30;
        this.tipo = "Carreta";
    }
}
