package Lista_Heranca.Q01;

public class Cargo {
    private String cargo;

    public Cargo(String c) {
        this.cargo = c;
    }

    public String get_cargo() {
        return cargo;
    }
}
