package Lista_Heranca.Q03;

public class Tipo {
    private String tipo;

    public Tipo(String t) {
        this.tipo = t;
    }

    public void set_tipo(String t) {
        this.tipo = t;
    }

    public String get_tipo() {
        return this.tipo;
    }
}
